const express = require("express");
const {
  submitApplication,
  getAllApplicants
} = require("../controllers/applicantController");
const { validate } = require("../middlewares/validateRequest");
const { applicantSchema } = require("../validators/applicantValidator");
const { updateStatus } = require("../controllers/applicantController");
const { protect } = require("../middlewares/authMiddleware");
const { statusSchema } = require("../validators/statusValidator");
const { applyLimiter } = require("../middlewares/rateLimiter");









const router = express.Router();

router.post(
  "/apply",
  applyLimiter,
  validate(applicantSchema),
  submitApplication
);
router.get("/", protect, getAllApplicants);
router.patch(
  "/:id/status",
  protect,
  validate(statusSchema),
  updateStatus
);


module.exports = router;


